import React from 'react'

const Register = () => {
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const username = form.username.value
    const password = form.password.value
    const role = form.role.value

    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/auth/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password, role }),
    })

    if (response.ok) {
      alert('Registration successful. Please log in.')
    } else {
      const data = await response.json()
      alert(`Registration failed: ${data.msg}`)
    }
  }

  return (
    <section id="register" className="mb-8">
      <h2 className="text-2xl font-bold mb-4">Register</h2>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <input type="text" name="username" placeholder="Username" required className="w-full p-2 border rounded" />
        </div>
        <div>
          <input type="password" name="password" placeholder="Password" required className="w-full p-2 border rounded" />
        </div>
        <div>
          <select name="role" required className="w-full p-2 border rounded">
            <option value="">Select Role</option>
            <option value="patient">Patient</option>
            <option value="doctor">Doctor</option>
          </select>
        </div>
        <button type="submit" className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">Register</button>
      </form>
    </section>
  )
}

export default Register

