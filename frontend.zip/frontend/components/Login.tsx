import React, { useState } from 'react'
import { signIn } from 'next-auth/react'

const Login = () => {
  const [error, setError] = useState('')

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setError('')
    const form = e.currentTarget
    const username = form.username.value
    const password = form.password.value
    const result = await signIn('credentials', {
      username,
      password,
      redirect: false,
    })
    if (result?.error) {
      setError(result.error)
    }
  }

  return (
    <section id="login" className="mb-8">
      <h2 className="text-2xl font-bold mb-4">Login</h2>
      {error && <p className="text-red-500 mb-4">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <input type="text" name="username" placeholder="Username" required className="w-full p-2 border rounded" />
        </div>
        <div>
          <input type="password" name="password" placeholder="Password" required className="w-full p-2 border rounded" />
        </div>
        <button type="submit" className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">Login</button>
      </form>
    </section>
  )
}

export default Login

