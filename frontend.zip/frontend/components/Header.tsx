import React from 'react'
import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'

const Header = () => {
  const { data: session } = useSession()

  return (
    <header className="bg-blue-600 text-white p-4">
      <nav className="container mx-auto flex justify-between items-center">
        <Link href="/" className="text-2xl font-bold">
          Secure PDS
        </Link>
        <ul className="flex space-x-4">
          {!session ? (
            <>
              <li><Link href="/#login">Login</Link></li>
              <li><Link href="/#register">Register</Link></li>
            </>
          ) : (
            <>
              <li><Link href="/files">My Files</Link></li>
              <li><button onClick={() => signOut()}>Logout</button></li>
            </>
          )}
        </ul>
      </nav>
    </header>
  )
}

export default Header

