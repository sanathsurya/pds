import React, { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'

const Files = () => {
  const { data: session } = useSession()
  const [files, setFiles] = useState([])

  useEffect(() => {
    const fetchFiles = async () => {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/files/list`, {
        headers: {
          'Authorization': `Bearer ${session?.accessToken}`,
        },
      })
      if (response.ok) {
        const data = await response.json()
        setFiles(data)
      }
    }

    if (session) {
      fetchFiles()
    }
  }, [session])

  const handleUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const form = e.currentTarget
    const file = form.file.files[0]
    const formData = new FormData()
    formData.append('file', file)

    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/files/upload`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${session?.accessToken}`,
      },
      body: formData,
    })

    if (response.ok) {
      alert('File uploaded successfully')
      // Refresh the file list
      const fetchResponse = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/files/list`, {
        headers: {
          'Authorization': `Bearer ${session?.accessToken}`,
        },
      })
      if (fetchResponse.ok) {
        const data = await fetchResponse.json()
        setFiles(data)
      }
    } else {
      alert('File upload failed')
    }
  }

  return (
    <section className="mb-8">
      <h2 className="text-2xl font-bold mb-4">My Files</h2>
      <div className="mb-4">
        {files.map((file: any) => (
          <div key={file.id} className="p-2 bg-gray-100 mb-2 rounded">{file.name}</div>
        ))}
      </div>
      <form onSubmit={handleUpload} className="space-y-4">
        <div>
          <input type="file" name="file" required className="w-full p-2 border rounded" />
        </div>
        <button type="submit" className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700">Upload File</button>
      </form>
    </section>
  )
}

export default Files

