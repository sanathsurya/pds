import React from 'react'
import { useSession } from 'next-auth/react'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import Files from '@/components/Files'

const FilesPage = () => {
  const { data: session } = useSession()

  if (!session) {
    return <div>Please log in to view this page</div>
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <Files />
      </main>
      <Footer />
    </div>
  )
}

export default FilesPage

